<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=lms',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
