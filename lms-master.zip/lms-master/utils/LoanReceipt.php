<?php
/**
 * Created by PhpStorm.
 * User: Supun
 * Date: 8/13/2017
 * Time: 10:43 AM
 */

namespace app\utils;


class LoanReceipt
{
    public $loan;

    public $loan_description;

    public $loan_amount;

    public $amount;

    public $amount_text;

    public $customer;
}